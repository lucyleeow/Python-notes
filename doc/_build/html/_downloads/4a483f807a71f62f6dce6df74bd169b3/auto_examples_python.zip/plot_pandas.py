# -*- coding: utf-8 -*-
"""
Pandas
#######

fff
"""

#%%
# dtype - object - means Python object - meaning could be anything and thus
# difficult to work with.
# Pandas is working on string object.

#%%
# loc vs iloc
# ************
#
# * **loc** - used for subsetting by reference  - e.g. to column names,
#   index (rowname)
# * **iloc** - used for subsetting by position
#
